export const environment = {
  production: false,
  firebaseAPIKey:'AIzaSyCu4uZPHnxBFO17dGRVSTFwUeL6RyQpBXQ'
};
