import { Component, OnInit } from '@angular/core';

interface Post {
  imageUrl: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  posts: Post[] = [
    { imageUrl: 'path-to-your-image1.jpg', title: 'Post 1', description: 'Description 1' },
    { imageUrl: 'path-to-your-image2.jpg', title: 'Post 2', description: 'Description 2' },
    { imageUrl: 'path-to-your-image3.jpg', title: 'Post 3', description: 'Description 3' },
    // Add more posts as needed
  ];

  constructor() {}

  ngOnInit() {}
}
