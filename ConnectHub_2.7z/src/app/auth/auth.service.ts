import { Injectable } from '@angular/core';
import {User} from "./user.model";
import {HttpClient} from "@angular/common/http";
import {map} from "rxjs";
import {environment} from "../../environments/environment";

interface UserData {
  name: string;
  surname: string;
  username: string;
  email: string;
  password:string;

}
interface AuthResponseData{
  kind:string,
  idToken:string,
  email: string,
  refreshToken:string,
  localId:string,
  expiresIn:string,
  registered?:boolean
}
@Injectable({
  providedIn: 'root'
})

export class AuthService {
  private _users:User[]=[];

  private baseUrl = 'https://connecthub-mobile-computing-default-rtdb.europe-west1.firebasedatabase.app';
  private _isUserAuthenticated!: boolean;

  constructor(private http: HttpClient) { }

  get user():User[]{
    return this._users;
  }

  register(user:UserData) {
    this._isUserAuthenticated = true;
    return this.http.post<AuthResponseData>(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${environment.firebaseAPIKey}`,
      {email: user.email, password: user.password, returnSecureToken: true});
  }

  get isUserAuthenticated():boolean{
    return this._isUserAuthenticated;
  }

  logIn(user:UserData){
    return this.http.post<AuthResponseData>(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${environment.firebaseAPIKey}`,
      {email: user.email, password: user.password, returnSecureToken: true});
    this._isUserAuthenticated = true;
  }
  logOut(){
    this._isUserAuthenticated=false;
  }
}
