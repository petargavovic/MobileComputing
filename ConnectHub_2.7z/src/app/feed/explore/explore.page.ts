import { Component, OnInit } from '@angular/core';
import { Feed } from '../feed.model';
import { ExploreService } from '../explore.service';
import {ModalController} from "@ionic/angular";
import {FeedModalComponent} from "../feed-modal/feed-modal.component";

@Component({
  selector: 'app-explore',
  templateUrl: './explore.page.html',
  styleUrls: ['./explore.page.scss'],
})
export class ExplorePage implements OnInit {
  feeds: Feed[] = [];

  constructor(private exploreService: ExploreService, private modalCtrl:ModalController) {}

  ngOnInit() {

  }
  ionViewWillEnter(){
    this.exploreService.getFeedDetails().subscribe((feeds )=>{
      this.feeds=feeds;
    })
  }
  openModal(){
    this.modalCtrl.create({
      component:FeedModalComponent,
      componentProps:{title:'Add post'}
    }).then((modal)=>{
      modal.present();
      return modal.onDidDismiss();
    }).then((resultData)=>{
        if(resultData.role==='confirm'){
          console.log(resultData);
          this.exploreService.addFeedDetail(resultData.data.feedData.description,
            resultData.data.feedData.imageUrl, resultData.data.feedData.title).subscribe((feeds)=>{
              this.feeds=feeds;
          })
        }
    });
  }
}
