import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feed-details',
  templateUrl: './feed-details.page.html',
  styleUrls: ['./feed-details.page.scss'],
})
export class FeedDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
