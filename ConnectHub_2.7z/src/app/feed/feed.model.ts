export interface Feed {
  id:string;
  imageUrl: string;
  description: string;
  title:string;
}
