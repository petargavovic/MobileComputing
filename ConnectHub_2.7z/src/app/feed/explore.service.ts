import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Feed } from './feed.model';
import {map} from "rxjs";

interface FeedData {
  title: string;
  description: string;
  imageUrl: string;
}

@Injectable({
  providedIn: 'root'
})
export class ExploreService {
  private _feeds:Feed[]=[];

  private baseUrl = 'https://connecthub-mobile-computing-default-rtdb.europe-west1.firebasedatabase.app';

  constructor(private http: HttpClient) {}

  get feed():Feed[]{
    return this._feeds;
  }
  addFeedDetail(description: string, imageUrl: string, title: string) {
    return this.http.post<{ name: string }>(
      `${this.baseUrl}/feeds.json`,
      { description, imageUrl, title }
    ).pipe(map((resData)=>{
      this._feeds.push({
        id:resData.name,
        description,
        title,
        imageUrl
      })
      return this._feeds;
    }));

  }

  getFeedDetails() {
    return this.http.get<{ [key: string]: FeedData }>(
      `${this.baseUrl}/feeds.json`
    ).pipe(map((feedsData)=>{
      const feeds: Feed[] =[];

      for(const key in feedsData){
        if(feedsData.hasOwnProperty(key)){
          feeds.push({
            id:key,
            description:feedsData[key].description,
            imageUrl:feedsData[key].imageUrl,
            title:feedsData[key].title
          })
        }
      }
      this._feeds=feeds;
      return feeds;
    }));
  }

  getFeedDetail(id: string) {
    return this.http.get<FeedData>(
      `${this.baseUrl}/feeds/${id}.json`
    );
  }
}
